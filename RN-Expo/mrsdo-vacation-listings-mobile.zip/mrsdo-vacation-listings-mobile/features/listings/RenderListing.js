/*
 * RenderListings.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * Serves as the 'layout presentation' for Listings
 * page content is loading.
 * ------------
 */
import { Text, View } from 'react-native';
import { Card } from 'react-native-elements';

const RenderListing = ({ listing }) => {
    if (listing) {
        return (
            <Card containerStyle={{ padding: 0 }}>
             <Card.Image source={listing.avatar_url}/>
                
                <Text style={{ margin: 20 }}>{listing.description}</Text>
            </Card>
        );
    }
    return <View />;
};

export default RenderListing;