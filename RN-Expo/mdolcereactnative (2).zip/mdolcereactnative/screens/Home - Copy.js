/* ../screens/Home.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file is creates a readable directory of onboarding activities pulled from the activities.js file.
 * ------------
 */

import React, { useState } from 'react';
import { FlatList } from 'react-native';
import { Avatar, ListItem, Card } from 'react-native-elements';

// Import Local
import { ACTIVITIES } from '../data/activities';
import Theme from '../theme/Theme';

// Start
const Home = ({ navigation }) => {
  const [activities, setActivities] = useState(ACTIVITIES);

  //  NOTE: Add Slices for these using store, Async, dispatch to setActivities...

  const renderActivityItem = ({ item: activity }) => {
    return (
      <ListItem
        onPress={() => navigation.navigate('ActivityInfo', { item: activity })}>
        <Avatar source={{ uri: activity.image }} />
        <ListItem.Content>
          <ListItem.Title>{activity.name}</ListItem.Title>
          <ListItem.Subtitle>{activity.description}</ListItem.Subtitle>
        </ListItem.Content>
      </ListItem>
    );
  };
  return (
    <FlatList
      data={activities}
      renderItem={renderActivityItem}
      keyExtractor={(item) => item.id.toString()}
    />
  );
};
export default Home;
