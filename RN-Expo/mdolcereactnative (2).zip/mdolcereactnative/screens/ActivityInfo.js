/*
 * ../screens/ActivityInfo.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file serves as a Activity 'Detail' Screen
 * ------------
 */

import RenderActivities from "../features/RenderActivities";

const ActivityInfo = ({route}) => {
    const { activity} = route.params;
    return <RenderActivities activity={activity} />;
};

export default ActivityInfo;