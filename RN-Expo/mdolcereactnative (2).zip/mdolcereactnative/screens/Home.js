/* ../screens/Home.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file is creates a readable directory of onboarding activities pulled from the activities.js file.
 * ------------
 */

import React, { useState } from 'react';
import { FlatList } from 'react-native';
import { StyleSheet } from 'react-native-elements';
import { Button, Card, Title, Paragraph } from 'react-native-paper';

// Import Local
import { ACTIVITIES } from '../data/activities';
import Theme from '../theme/Theme';

// Start
const Home = ({ navigation }) => {
  const [activities, setActivities] = useState(ACTIVITIES);

  //  NOTE: Add Slices for these using store, Async, dispatch to setActivities...

  const renderActivityItem = ({ item: activity }) => {
    return (
      <Card
        style={{
          flex: 1,
          justifyContent: 'space-between',
          backgroundColor: '#fff',
          padding: 10,
          margin: 10,
          width: 300

        }}>
        <Card.Content>
          <Title style={{
            color: 'gray',
          }}>{activity.name}</Title>
          <Paragraph style={{
            color: 'gray',
          }}>{activity.heading }</Paragraph>
        </Card.Content>
        <Card.Cover source={activity.image}
          style={{
            color: 'gray',
          }}
        />
        <Card.Actions>
          <Button>Cancel</Button>
          <Button>Ok</Button>
        </Card.Actions>
      </Card>
    );
  };
  
  return (
    <FlatList
      data={activities}
      renderItem={renderActivityItem}
      keyExtractor={(item) => item.id.toString()}
    />
  );
};



export default Home;
