 /* App.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file is provides loading capabilities and a splash page while the
 * page content is loading.
 * ------------
 */
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { Platform } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppRegistry } from 'react-native';

import { MD3LightTheme as DefaultTheme, Provider as PaperProvider } from 'react-native-paper';
import MainMenu from './navigation/MainMenu';



export default function App() {
  return (
    <SafeAreaProvider>
      <PaperProvider>
        <MainMenu />
      </PaperProvider>
    </SafeAreaProvider>
  );
}
