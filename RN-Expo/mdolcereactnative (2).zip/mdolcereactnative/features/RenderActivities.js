/*
 * ../features/RenderActivities.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * Serves as the 'layout presentation' for OnBoarding Activities.
 * ------------
 */

import { Text, View } from 'react-native';
import { Card } from 'react-native-elements';

const RenderActivities = ({ activity }) => {
    if (activity) {
        return (
            <Card containerStyle={{ padding: 0 }}>
                <Card.Image source={image}>
                    <View style={{ justifyContent: 'center', flex: 1 }}>
                        <Text
                            style={{
                                color: 'white',
                                textAlign: 'center',
                                fontSize: 20
                            }}
                        >
                            {activity.name}
                        </Text>
                    </View>
                </Card.Image>
                <Text style={{ margin: 20 }}>{activity.description}</Text>
            </Card>
        );
    }
    return <View />;
};

export default RenderActivities;