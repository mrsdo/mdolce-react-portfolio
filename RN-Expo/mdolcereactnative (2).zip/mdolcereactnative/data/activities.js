export const ACTIVITIES = [
    {
        id: 0,
        name: "Home",
        image: require("../assets/images/image-00.png"),
        heading: "Hello, and welcome! We Are Glad You're Here.",
        required: false,
        description: "We're so glad you are joining our team! Here you'll find resources to ensure you feel prepared and supported for your first day at your new job."
    },
    {
      
        id: 1,
        name:"Onboarding ",
        image: require("../assets/images/image-01.png"),
        heading: "​​​​​​Prepare for your first day",
        required: true,
        description: "​​​​​​​Get ready by reviewing the first-day checklist, confirming logistical details, and collecting two forms of identification."
    },

    {
        id: 3,
        name:"Registration",
        image: require("../assets/images/image-03.png"),
        heading: "Access Your New Account",
        required: false,
        description: "If you haven't been assigned a new account, use this form to request temporary access."
    },
    
];