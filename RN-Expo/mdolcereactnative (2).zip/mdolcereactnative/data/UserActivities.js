export const USER_ACTIVITIES = [
    {
      
        id: 1,
        name:"Onboarding ",
        image: require("../assets/images/image-01.png"),
        heading: "​​​​​​Prepare for your first day",
        required: true,
        description: "​​​​​​​Get ready by reviewing the first-day checklist, confirming logistical details, and collecting two forms of identification."
    },
    {
        id: 2,
        name:"User Login",
        image: require("../assets/images/image-02.png"),
        heading: "Welcome Back, ",
        required: false,
        description: "Login to access your account."
    },
    {
        id: 3,
        name:"Registration",
        image: require("../assets/images/image-03.png"),
        heading: "Access Your New Account",
        required: false,
        description: "If you haven't been assigned a new account, use this form to request temporary access."
    },
    {
        id: 4,
        name:"Sign-out",
        image: require("../assets/images/image-03.png"),
        heading: "Thanks for Visiting",
        required: false,
        description: "For your security, your session has ended."
    },
    {
        id: 5,
        name:"Profile",
        image: require("../assets/images/image-02.png"),
        heading: "Welcome Back, ",
        required: false,
        description: "This is your user dashboard. From here you can access your personal information."
    },
];