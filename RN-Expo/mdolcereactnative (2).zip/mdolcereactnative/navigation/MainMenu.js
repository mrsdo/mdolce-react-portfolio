 /* .../navigation/MainMenu.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file is provides Navigation and ports in screens (Home, OnBoarding, User Login, Registration).
 * 
 * NOTE: Make a component for: Login/Registration Success and Logout
 * ------------
 */
import * as React from 'react';
import { Button, View, Text, StyleSheet } from 'react-native';
import { Appbar, Menu } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Import Local
import Home from '../screens/Home';
import Theme from '../theme/Theme';

// Start App
const Stack = createStackNavigator();

// Exported MainMenu
export default function MainMenu() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="HomeScreen"
        screenOptions={{
          header: CustomNavigationBar,
        }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="OnBoarding" component={OnBoarding} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Register" component={Register} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// I like to keep my functional components at the bottom

// Custom Navigation
function CustomNavigationBar({ navigation, back }) {
  const [visible, setVisible] = React.useState(false);
  const openMenu = () => setVisible(true);
  const closeMenu = () => setVisible(false);

  return (
    <Appbar.Header style={styles.AppHeader}>
      {back ? <Appbar.BackAction onPress={navigation.goBack} /> : null}
      <Appbar.Content
        title="~M.Dolce"
        color={Theme.COLORS.WHITE}
        subtitle={'User Onboarding Demo'}
      />
      {!back ? (
        <Menu
          visible={visible}
          onDismiss={closeMenu}
          anchor={
            <Appbar.Action
              icon="menu"
              color={Theme.COLORS.WHITE}
              onPress={openMenu}
            />
          }>
          <Menu.Item
            onPress={() => {
              navigation.navigate('Home');
            }}
            title="Home"
          />
          <Menu.Item
            onPress={() => {
              navigation.navigate('OnBoarding');
            }}
            title="OnBoarding"
          />
          <Menu.Item
            onPress={() => {
              navigation.navigate('Login');
            }}
            title="Login"
          />
          <Menu.Item
            onPress={() => {
              navigation.navigate('Register');
            }}
            title="Register"
          />
        </Menu>
      ) : null}
    </Appbar.Header>
  );
}

/*
 *  Function HomePage
 */
function HomeScreen() {
  return (
    <View style={styles.container}>
    <Home />
      <Text style={styles.textContainer}>Home Screen</Text>
    </View>
  );
}

/*
 *  Function OnBoarding
 */
function OnBoarding() {
  return (
    <View style={styles.container}>
      <Text style={styles.textContainer}>OnBoarding Screen</Text>
    </View>
  );
}


/*
 *  Function User Login
 */
function Login() {
  return (
    <View style={styles.container}>
      <Text style={styles.textContainer}>Login Screen</Text>
    </View>
  );
}

/*
 *  Function Registration
 */
function Register() {
  return (
    <View style={styles.container}>
      <Text style={styles.textContainer}>Registration Screen</Text>
    </View>
  );
}

/*
 *  Function Styles
 */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  AppHeader: {
    backgroundColor: Theme.COLORS.PRIMARY,
    color: '#ffffff',
  },

  textContainer: {
    fontFamily: 'Varela Round',
    top: 30,
    position: 'Relative',
    letterSpacing: 2,
    fontSize: 18,
    color: Theme.COLORS.DEFAULT,
    textAlign: 'center',
  },
});
