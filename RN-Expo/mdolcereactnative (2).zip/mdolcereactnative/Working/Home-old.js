/*
 * /screens/Home.js | M.Dolce, React Native Portfolio, marti.dolce@29signals.org, 202212
 * Function ---
 * This file is provides loading capabilities and a splash page while the
 * page content is loading.
 * ------------
 */

import React, { useCallback, useEffect, useState } from 'react';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ImageBackground,
  Animated,
  Platform,
} from 'react-native';

import Theme from '../theme/Theme';

const image = {
  uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/5acd7c9cd024f3701aca01bab7ff281b',
};

SplashScreen.preventAutoHideAsync();

const Home = (props) => {
  const [appIsReady, setAppIsReady] = useState(false);
  // load Image-background URL

  useEffect(() => {
    async function prepareImageBackground() {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      } catch (err) {
        console.warn(err);
      } finally {
        setAppIsReady(true);
      }
    }

    prepareImageBackground().then((r) => {
      if (r) {
        setAppIsReady(true);
      }
    });
  }, []);

  const onLayoutRootView = useCallback(async () => {
    if (appIsReady) {
      await SplashScreen.hideAsync();
    }
  }, [appIsReady]);

  if (!appIsReady) {
    return null;
  }

  return <LoadImage />;
};

// Load the background image
function LoadImage() {
  return (
    <View style={styles.container}>
      <Text style={styles.textContainer}>Home Screen</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },


  textContainer: {
    fontFamily: 'Varela Round',
    top: 30,
    position: 'Relative',
    letterSpacing: 2,
    fontSize: 18,
    color: Theme.COLORS.DEFAULT,
    textAlign: 'center',
  },
});

export default Home;
